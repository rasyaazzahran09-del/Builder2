import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// =====================================================
// STALKER OSINT PAGE — Cek info publik sosial media
// Menggunakan api.siputzx.my.id — Tanpa server
// =====================================================

class StalkerPage extends StatefulWidget {
  const StalkerPage({super.key});

  @override
  State<StalkerPage> createState() => _StalkerPageState();
}

class _StalkerPageState extends State<StalkerPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _igCtrl = TextEditingController();
  final TextEditingController _ttCtrl = TextEditingController();
  final TextEditingController _ghCtrl = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _result;
  String _activeSource = '';

  static const String _apiBase = 'https://api.siputzx.my.id';

  final Color _bg    = const Color(0xFF0B0E14);
  final Color _card  = const Color(0xFF151A23);
  final Color _red   = const Color(0xFFEF4444);
  final Color _border = const Color(0xFF252B36);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _igCtrl.dispose();
    _ttCtrl.dispose();
    _ghCtrl.dispose();
    super.dispose();
  }

  // ── Instagram Info (data profil publik) ──
  Future<void> _checkInstagram() async {
    final user = _igCtrl.text.trim().replaceAll('@', '');
    if (user.isEmpty) return;
    _startLoad('instagram');

    try {
      final res = await http.get(
        Uri.parse('$_apiBase/api/stalker/ig?user=$user'),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == true) {
          setState(() => _result = _flattenMap(data['data'] ?? data['result'] ?? {}));
          return;
        }
      }

      // fallback endpoint
      final res2 = await http.get(
        Uri.parse('$_apiBase/api/tools/ig-info?username=$user'),
      ).timeout(const Duration(seconds: 15));
      if (res2.statusCode == 200) {
        final data2 = jsonDecode(res2.body);
        if (data2['status'] == true) {
          setState(() => _result = _flattenMap(data2['data'] ?? data2['result'] ?? {}));
          return;
        }
      }

      setState(() => _result = {'info': 'Data tidak ditemukan atau profil private'});
    } catch (e) {
      setState(() => _result = {'error': '$e'});
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // ── TikTok Info ──
  Future<void> _checkTikTok() async {
    final user = _ttCtrl.text.trim().replaceAll('@', '');
    if (user.isEmpty) return;
    _startLoad('tiktok');

    try {
      final res = await http.get(
        Uri.parse('$_apiBase/api/stalker/tiktok?username=$user'),
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == true) {
          setState(() => _result = _flattenMap(data['data'] ?? data['result'] ?? {}));
          return;
        }
      }

      final res2 = await http.get(
        Uri.parse('$_apiBase/api/tools/tiktok-info?username=$user'),
      ).timeout(const Duration(seconds: 15));
      if (res2.statusCode == 200) {
        final data2 = jsonDecode(res2.body);
        if (data2['status'] == true) {
          setState(() => _result = _flattenMap(data2['data'] ?? data2['result'] ?? {}));
          return;
        }
      }

      setState(() => _result = {'info': 'Data tidak ditemukan'});
    } catch (e) {
      setState(() => _result = {'error': '$e'});
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // ── GitHub Info ──
  Future<void> _checkGitHub() async {
    final user = _ghCtrl.text.trim();
    if (user.isEmpty) return;
    _startLoad('github');

    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/users/$user'),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() => _result = {
          'name':       data['name'] ?? '-',
          'username':   data['login'] ?? '-',
          'bio':        data['bio'] ?? '-',
          'company':    data['company'] ?? '-',
          'location':   data['location'] ?? '-',
          'email':      data['email'] ?? '-',
          'blog':       data['blog'] ?? '-',
          'followers':  '${data['followers'] ?? 0}',
          'following':  '${data['following'] ?? 0}',
          'repos':      '${data['public_repos'] ?? 0}',
          'created_at': data['created_at'] ?? '-',
          'avatar_url': data['avatar_url'] ?? '',
        });
        return;
      }
      setState(() => _result = {'info': 'User GitHub tidak ditemukan'});
    } catch (e) {
      setState(() => _result = {'error': '$e'});
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _startLoad(String src) {
    setState(() { _isLoading = true; _result = null; _activeSource = src; });
  }

  Map<String, dynamic> _flattenMap(dynamic data, [String prefix = '']) {
    final result = <String, dynamic>{};
    if (data is Map) {
      data.forEach((k, v) {
        final key = prefix.isEmpty ? '$k' : '$prefix.$k';
        if (v is Map || v is List) {
          result.addAll(_flattenMap(v, key));
        } else {
          result[key] = v;
        }
      });
    } else if (data is List) {
      for (int i = 0; i < data.length && i < 10; i++) {
        result.addAll(_flattenMap(data[i], '${prefix}[$i]'));
      }
    }
    return result;
  }

  void _copyAll() {
    if (_result == null) return;
    final text = _result!.entries.map((e) => '${e.key}: ${e.value}').join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Disalin ke clipboard!'),
      backgroundColor: Color(0xFF4CAF50),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('OSINT Stalker',
            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: _red,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.grey,
          tabs: const [
            Tab(icon: Icon(Icons.camera_alt, size: 18), text: 'Instagram'),
            Tab(icon: Icon(Icons.smart_display, size: 18), text: 'TikTok'),
            Tab(icon: Icon(Icons.code, size: 18), text: 'GitHub'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildTab('Instagram', '@username', _igCtrl, _checkInstagram, const Color(0xFFE1306C)),
          _buildTab('TikTok', '@username', _ttCtrl, _checkTikTok, const Color(0xFFFE2C55)),
          _buildTab('GitHub', 'username', _ghCtrl, _checkGitHub, const Color(0xFF6E5494)),
        ],
      ),
    );
  }

  Widget _buildTab(String label, String hint, TextEditingController ctrl, VoidCallback onSearch, Color color) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        // Input
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _border)),
          child: Column(children: [
            Row(children: [
              Expanded(
                child: TextField(
                  controller: ctrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: const TextStyle(color: Colors.grey),
                    filled: true,
                    fillColor: _bg,
                    prefixIcon: Icon(Icons.person_search, color: color),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  ),
                  onSubmitted: (_) => onSearch(),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _isLoading ? null : onSearch,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)),
                  child: _isLoading
                      ? const SizedBox(width: 22, height: 22,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.search, color: Colors.white),
                ),
              ),
            ]),
          ]),
        ),

        const SizedBox(height: 16),

        // Result
        if (_result != null && _activeSource == label.toLowerCase())
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(16),
                border: Border.all(color: color.withOpacity(0.4))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Avatar jika ada
              if (_result!['avatar_url'] != null && _result!['avatar_url'].toString().isNotEmpty)
                Center(child: Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(60),
                    child: Image.network(_result!['avatar_url'].toString(),
                        width: 80, height: 80, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const SizedBox()),
                  ),
                )),

              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Hasil OSINT — $label',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 12)),
                IconButton(
                  icon: const Icon(Icons.copy, color: Colors.grey, size: 18),
                  onPressed: _copyAll,
                  tooltip: 'Copy semua',
                ),
              ]),
              const Divider(color: Colors.grey),
              const SizedBox(height: 4),

              ..._result!.entries
                  .where((e) => e.key != 'avatar_url' && e.value != null && e.value.toString().isNotEmpty && e.value.toString() != 'null')
                  .map((e) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(flex: 2,
                        child: Text(e.key.replaceAll('_', ' '),
                            style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold))),
                      Expanded(flex: 3,
                        child: Text('${e.value}',
                            style: const TextStyle(color: Colors.white, fontSize: 12))),
                    ]),
                  )),
            ]),
          ),

        if (_isLoading && _activeSource == label.toLowerCase())
          const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: CircularProgressIndicator(color: Color(0xFFEF4444))),
          ),
      ]),
    );
  }
}
