import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const _baseUrl = 'http://panel-legal.jhonaley.net:2983';

// ─── Palette ──────────────────────────────────────────────────────────────────
class _C {
  static const bg         = Colors.transparent;
  static const surface    = Color(0x880C1424);
  static const card       = Color(0x99101A2E);
  static const cardSolid  = Color(0xFF101A2E);
  static const border     = Color(0x661A2D4A);
  static const borderLit  = Color(0x661E3A5F);
  static const blue       = Color(0xFF1B6FBD);
  static const blueMid    = Color(0xFF2D8FE8);
  static const blueLight  = Color(0xFF56AEF5);
  static const blueFrost  = Color(0xFF90CEF7);
  static const cyan       = Color(0xFF00D4FF);
  static const cyanDim    = Color(0xFF0EA5E9);
  static const green      = Color(0xFF22C55E);
  static const greenDim   = Color(0xFF16A34A);
  static const amber      = Color(0xFFF59E0B);
  static const red        = Color(0xFFEF4444);
  static const text       = Color(0xFFE2EDF9);
  static const textSub    = Color(0xFF7A9BBF);
  static const textDim    = Color(0xFF3A5470);
  static const purple     = Color(0xFF8B5CF6);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [blueMid, blueLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':     return const Color(0xFFF59E0B);
    case 'admin':     return const Color(0xFFEF4444);
    case 'moderator': return const Color(0xFF22C55E);
    case 'partner':   return const Color(0xFF8B5CF6);
    case 'vip':       return const Color(0xFFEC4899);
    case 'reseller':  return const Color(0xFF22C55E);
    default:          return _C.blueLight;
  }
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetCtrl = TextEditingController();
  final loopCtrl = TextEditingController(text: '2');

  String selectedBugId = '';
  int    _selectedBugIndex = 0;
  String _bugMode      = 'number';
  String _senderType   = 'private'; 
  bool   _isSending    = false;
  String? _responseMsg;

  List<String> _globalSenders   = [];
  bool         _isLoadingSenders = false;

  // Animation Controllers
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sendBtnCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _waveCtrl;
  late AnimationController _popupScaleCtrl; // Animasi khusus popup kecil

  late Animation<double> _entrance;
  late Animation<double> _sendPulse;
  late Animation<double> _sendGlow;
  late Animation<double> _resultFade;
  late Animation<Offset>  _resultSlide;
  late Animation<double> _popupScaleAnim;

  // Video Controllers
  late VideoPlayerController _backgroundVideoCtrl; 
  bool _bgVideoReady = false;

  late VideoPlayerController _attackVideoCtrl;    
  bool _attackVideoReady = false;
  
  // Custom Loop Logic
  int _loopCount = 0;
  int _maxLoops = 2; 

  late PageController _bugPageCtrl;

  bool get canAccessPublicSender => true; 
  bool get canAccessGoib => true; 

  @override
  void initState() {
    super.initState();
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
      _selectedBugIndex = 0;
    }

    _bugPageCtrl = PageController(viewportFraction: 0.72);

    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sendBtnCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _sendPulse = Tween<double>(begin: 1.0, end: 1.05)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _sendGlow = Tween<double>(begin: 0.25, end: 0.65)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));

    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade  = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _waveCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();

    // Animasi untuk Popup Kecil (Scale dari 0 ke 1)
    _popupScaleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _popupScaleAnim = CurvedAnimation(parent: _popupScaleCtrl, curve: Curves.elasticOut);

    _entranceCtrl.forward();
    
    _initBackgroundVideo();
    _initAttackVideo(); 
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sendBtnCtrl.dispose();
    _resultCtrl.dispose();
    _waveCtrl.dispose();
    _popupScaleCtrl.dispose();
    _bugPageCtrl.dispose();
    targetCtrl.dispose();
    loopCtrl.dispose();
    _backgroundVideoCtrl.dispose();
    _attackVideoCtrl.dispose();
    super.dispose();
  }

  void _initBackgroundVideo() {
    _backgroundVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4');
    _backgroundVideoCtrl.initialize().then((_) {
      if (!mounted) return;
      _backgroundVideoCtrl.setVolume(0);
      _backgroundVideoCtrl.setLooping(true); 
      _backgroundVideoCtrl.play();
      setState(() => _bgVideoReady = true);
    });
  }

  void _initAttackVideo() {
    _attackVideoCtrl = VideoPlayerController.asset('assets/videos/bokep.mp4');
    _attackVideoCtrl.initialize().then((_) {
      if (!mounted) return;
      _attackVideoCtrl.setVolume(0); 
      setState(() => _attackVideoReady = true);
      _attackVideoCtrl.addListener(_checkAttackVideoLoop);
    });
  }

  void _checkAttackVideoLoop() {
    if (_attackVideoCtrl.value.position >= _attackVideoCtrl.value.duration && 
        _isSending && 
        _loopCount < _maxLoops - 1) {
      _loopCount++;
      _attackVideoCtrl.seekTo(Duration.zero);
      _attackVideoCtrl.play();
    } else if (_attackVideoCtrl.value.position >= _attackVideoCtrl.value.duration) {
      _stopAttackSequence();
    }
  }

  void _startAttackSequence() {
    if (!_attackVideoReady) return;
    
    final inputLoop = int.tryParse(loopCtrl.text);
    if (inputLoop != null && inputLoop > 0) {
      _maxLoops = inputLoop;
    } else {
      _maxLoops = 1;
    }

    setState(() {
      _isSending = true;
      _responseMsg = null;
      _loopCount = 0; 
    });
    
    // Jalankan animasi pop-up
    _popupScaleCtrl.forward(from: 0);
    _resultCtrl.reset();
    
    _attackVideoCtrl.seekTo(Duration.zero);
    _attackVideoCtrl.play();
  }

  void _stopAttackSequence() {
    if (mounted) {
      _popupScaleCtrl.reverse(); // Animasi mengecil sebelum hilang
      Future.delayed(const Duration(milliseconds: 300), () {
        if(mounted) {
          setState(() => _isSending = false);
          _attackVideoCtrl.pause();
        }
      });
    }
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        '$_baseUrl/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) setState(() => _globalSenders = List<String>.from(data['senders']));
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? formatPhone(String s) {
    String c = s.replaceAll(RegExp(r'[^\d+]'), '');
    if (!c.startsWith('+')) {
      c = '+$c';
    }
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }

  bool isValidGroupLink(String s) =>
      s.startsWith('https://') && s.contains('chat.whatsapp.com');

  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key      = widget.sessionKey;

    String? finalTarget;
    
    if (_bugMode == 'number') {
      finalTarget = formatPhone(rawInput);
      if (finalTarget == null) {
        _showAlert('Nomor Tidak Valid', 'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert('Link Tidak Valid',
            'Masukkan link grup WhatsApp yang valid.\nContoh: https://chat.whatsapp.com/XXX');
        return;
      }
      finalTarget = rawInput;
    }

    if (_senderType == 'goib' && !canAccessGoib) {
       _showAlert('Akses Ditolak', 'Anda tidak memiliki akses Sender GOIB.');
       return;
    }

    if (selectedBugId.isEmpty) {
      _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.');
      return;
    }

    _startAttackSequence();

    try {
      final encodedTarget = Uri.encodeComponent(finalTarget);
      
      String senderParam = '';
      if (_senderType == 'public') senderParam = '&senderMode=global';
      if (_senderType == 'goib') senderParam = '&senderMode=goib';

      final url = Uri.parse(
        '$_baseUrl/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=$selectedBugId'
        '$senderParam',
      );

      final res  = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      _stopAttackSequence();

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final label = _bugMode == 'group' ? 'grup target' : finalTarget;
        final role  = data['role'] ?? widget.role;
        _setResponse('success', 'Bug berhasil dikirim ke $label! [$role]');
        targetCtrl.clear();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      _stopAttackSequence();
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    }
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMsg = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.cardSolid,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.amber.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: _C.amber.withOpacity(0.12), blurRadius: 40)],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.amber.withOpacity(0.1),
                border: Border.all(color: _C.amber.withOpacity(0.3)),
              ),
              child: const Icon(Icons.warning_amber_rounded, color: _C.amber, size: 26),
            ),
            const SizedBox(height: 14),
            Text(title, style: const TextStyle(color: _C.text, fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(msg, textAlign: TextAlign.center,
                style: const TextStyle(color: _C.textSub, fontSize: 13, height: 1.5)),
            const SizedBox(height: 22),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () => Navigator.pop(ctx)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(children: [
        // 1. Background
        Positioned.fill(child: _buildVideoBackground()),
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.60),
                  Colors.black.withOpacity(0.40),
                  Colors.black.withOpacity(0.70),
                ],
              ),
            ),
          ),
        ),
        Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),

        // 2. POP UP VIDEO KECIL (DI TENGAH LAYAR)
        if (_isSending && _attackVideoReady)
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(0.5), // Background setengah gelap
              child: Center(
                child: ScaleTransition(
                  scale: _popupScaleAnim,
                  child: Container(
                    width: MediaQuery.of(context).size.width * 0.8, // Lebar 80% layar
                    decoration: BoxDecoration(
                      color: _C.cardSolid,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: _C.cyan.withOpacity(0.4), width: 1.5),
                      boxShadow: [
                        BoxShadow(color: _C.cyan.withOpacity(0.25), blurRadius: 30, spreadRadius: 2)
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Area Video Kecil
                        AspectRatio(
                          aspectRatio: 16 / 9,
                          child: VideoPlayer(_attackVideoCtrl),
                        ),
                        
                        // Area Teks & Loading
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                          color: _C.cardSolid,
                          child: Column(
                            children: [
                              const _DotsLoader(),
                              const SizedBox(height: 16),
                              Text(
                                "ATTACKING TARGET... ($_loopCount/$_maxLoops)",
                                style: const TextStyle(
                                  color: _C.cyan, 
                                  fontSize: 16, 
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                "Mohon tunggu, bug sedang dikirim",
                                style: TextStyle(
                                  color: _C.textSub, 
                                  fontSize: 12,
                                ),
                                textAlign: TextAlign.center,
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

        // 3. KONTEN UTAMA UI
        SafeArea(
          child: FadeTransition(
            opacity: _entrance,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
              child: Column(children: [
                _buildProfileCard(),
                const SizedBox(height: 16),
                _buildModeToggle(),
                const SizedBox(height: 16),
                _buildTargetInput(),
                const SizedBox(height: 16),
                _buildBugCarousel(), 
                const SizedBox(height: 16),
                _buildSenderCard(), 
                const SizedBox(height: 16),
                _buildCustomLoopSection(),
                const SizedBox(height: 28),
                _buildSendButton(),
                const SizedBox(height: 12),
                if (_responseMsg != null) _buildResultBanner(),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildVideoBackground() {
    if (!_bgVideoReady) {
      return Container(color: const Color(0xFF060B14));
    }
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _backgroundVideoCtrl.value.size.width,
          height: _backgroundVideoCtrl.value.size.height,
          child: VideoPlayer(_backgroundVideoCtrl),
        ),
      ),
    );
  }

  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xCC0D1B2A),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.cyan.withOpacity(0.22), width: 1.2),
        boxShadow: [
          BoxShadow(color: _C.cyan.withOpacity(0.08), blurRadius: 24, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(children: [
        Row(children: [
          Container(
            width: 58, height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF0D2030),
              border: Border.all(color: _C.cyan.withOpacity(0.7), width: 2.5),
              boxShadow: [BoxShadow(color: _C.cyan.withOpacity(0.35), blurRadius: 16)],
            ),
            child: ClipOval(
              child: Center(
                child: Image.asset(
                  'assets/images/logo.png',
                  width: 38, height: 38,
                  errorBuilder: (_, __, ___) => Icon(Icons.shield_rounded, color: _C.cyan, size: 28),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.username, style: const TextStyle(color: _C.text, fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
            const SizedBox(height: 3),
            Text(widget.role.toUpperCase(), style: TextStyle(color: _C.cyan, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: const Color(0xFF0D2030), borderRadius: BorderRadius.circular(20), border: Border.all(color: _C.cyan.withOpacity(0.3))),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.access_time_rounded, color: _C.cyan, size: 12),
              const SizedBox(width: 5),
              Text(widget.expiredDate, style: const TextStyle(color: _C.text, fontSize: 11, fontWeight: FontWeight.w600)),
            ]),
          ),
        ]),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          decoration: BoxDecoration(color: const Color(0xFF0A1520), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(0.06))),
          child: IntrinsicHeight(
            child: Row(children: [
              Expanded(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 40, height: 40, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.cyan.withOpacity(0.12), border: Border.all(color: _C.cyan.withOpacity(0.4))), child: const Icon(Icons.bug_report_rounded, color: _C.cyan, size: 20)),
                const SizedBox(height: 8), Text('${widget.listBug.length}', style: const TextStyle(color: _C.text, fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 2), const Text('Total Bugs', style: TextStyle(color: _C.textSub, fontSize: 11))
              ])),
              VerticalDivider(color: Colors.white.withOpacity(0.08), width: 1),
              Expanded(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 40, height: 40, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.green.withOpacity(0.12), border: Border.all(color: _C.green.withOpacity(0.4))), child: const Icon(Icons.bolt_rounded, color: _C.green, size: 20)),
                const SizedBox(height: 8), const Text('GACOR', style: TextStyle(color: _C.green, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 2), const Text('Success Rate', style: TextStyle(color: _C.textSub, fontSize: 11))
              ])),
              VerticalDivider(color: Colors.white.withOpacity(0.08), width: 1),
              Expanded(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 40, height: 40, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.green.withOpacity(0.12), border: Border.all(color: _C.green.withOpacity(0.4))), child: const Icon(Icons.check_circle_rounded, color: _C.green, size: 20)),
                const SizedBox(height: 8), const Text('ACTIVE', style: TextStyle(color: _C.green, fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1)), const SizedBox(height: 2), const Text('Status', style: TextStyle(color: _C.textSub, fontSize: 11))
              ])),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _buildModeToggle() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: const Color(0xAA0D1B2A), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.1))),
      child: Row(children: [
        _ModeTab(icon: Icons.phone_android_rounded, label: 'Bug Nomor', active: _bugMode == 'number', onTap: () => setState(() { _bugMode = 'number'; targetCtrl.clear(); })),
        _ModeTab(icon: Icons.group_rounded, label: 'Bug Group', active: _bugMode == 'group', onTap: () => setState(() { _bugMode = 'group'; targetCtrl.clear(); })),
      ]),
    );
  }

  Widget _buildTargetInput() {
    return Container(
      decoration: BoxDecoration(color: const Color(0xBB0D1B2A), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(0.1))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.08)))), child: Row(children: [
          Container(width: 30, height: 30, decoration: BoxDecoration(color: _C.cyan.withOpacity(0.12), borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.cyan.withOpacity(0.4))), child: Icon(_bugMode == 'number' ? Icons.phone_android_rounded : Icons.link_rounded, color: _C.cyan, size: 15)),
          const SizedBox(width: 10), Text(_bugMode == 'number' ? 'NOMOR TARGET' : 'LINK GRUP TARGET', style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1)),
        ])),
        Padding(padding: const EdgeInsets.all(12), child: _BugInput(controller: targetCtrl, hint: _bugMode == 'number' ? '628xxxxxxxxxxx (Auto +)' : 'https://chat.whatsapp.com/...', keyboardType: _bugMode == 'number' ? TextInputType.phone : TextInputType.url, icon: Icons.language_rounded)),
      ]),
    );
  }

  Widget _buildBugCarousel() {
    if (widget.listBug.isEmpty) return const SizedBox();
    return Container(
      decoration: BoxDecoration(color: const Color(0xBB0D1B2A), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(0.1))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.08)))), child: Row(children: [
          Container(width: 30, height: 30, decoration: BoxDecoration(color: _C.red.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.red.withOpacity(0.5))), child: const Icon(Icons.bug_report_rounded, color: _C.red, size: 15)),
          const SizedBox(width: 10), const Text('PILIH BUG', style: TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1)),
        ])),
        const SizedBox(height: 12),
        SizedBox(
          height: 200, 
          child: PageView.builder(
            controller: _bugPageCtrl,
            itemCount: widget.listBug.length,
            onPageChanged: (i) {
              setState(() {
                _selectedBugIndex = i;
                selectedBugId = widget.listBug[i]['bug_id'];
              });
            },
            itemBuilder: (ctx, i) {
              final bug = widget.listBug[i];
              final isSelected = _selectedBugIndex == i;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 6),
                decoration: BoxDecoration(
                  color: isSelected ? _C.cyan.withOpacity(0.08) : Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: isSelected ? _C.cyan.withOpacity(0.6) : Colors.white.withOpacity(0.1), width: isSelected ? 1.5 : 1.0),
                  boxShadow: isSelected ? [BoxShadow(color: _C.cyan.withOpacity(0.2), blurRadius: 18)] : [],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () {
                      _bugPageCtrl.animateToPage(i, duration: const Duration(milliseconds: 350), curve: Curves.easeInOut);
                      setState(() { _selectedBugIndex = i; selectedBugId = bug['bug_id']; });
                    },
                    child: Stack(children: [
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.asset(
                                'assets/images/ppp.jpg', 
                                width: 100, height: 80, fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) => Container(width: 100, height: 80, color: _C.textDim.withOpacity(0.2), child: const Icon(Icons.broken_image, color: _C.textDim)),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text((bug['bug_name'] ?? 'Bug ${i + 1}').toString().toUpperCase(), style: TextStyle(color: isSelected ? _C.text : _C.textSub, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 0.8), maxLines: 1, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 5),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.white.withOpacity(0.12))),
                              child: Text(bug['bug_type'] ?? 'invisible', style: const TextStyle(color: _C.textSub, fontSize: 10, fontWeight: FontWeight.w600)),
                            ),
                          ],
                        ),
                      ),
                      if (isSelected)
                        Positioned(top: 8, right: 8, child: Container(width: 24, height: 24, decoration: const BoxDecoration(color: _C.green, shape: BoxShape.circle), child: const Icon(Icons.check_rounded, color: Colors.white, size: 14))),
                    ]),
                  ),
                ),
              );
            },
          ),
        ),
        Padding(padding: const EdgeInsets.only(top: 12, bottom: 14), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(widget.listBug.length, (i) => AnimatedContainer(duration: const Duration(milliseconds: 250), margin: const EdgeInsets.symmetric(horizontal: 3), width: _selectedBugIndex == i ? 22 : 7, height: 7, decoration: BoxDecoration(color: _selectedBugIndex == i ? _C.cyan : _C.textDim, borderRadius: BorderRadius.circular(4)))))),
      ]),
    );
  }

  Widget _buildSenderCard() {
    return Container(
      decoration: BoxDecoration(color: const Color(0xBB0D1B2A), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(0.1))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.08)))), child: Row(children: [
          Container(width: 30, height: 30, decoration: BoxDecoration(color: _C.cyan.withOpacity(0.12), borderRadius: BorderRadius.circular(8), border: Border.all(color: _C.cyan.withOpacity(0.4))), child: const Icon(Icons.swap_horiz_rounded, color: _C.cyan, size: 16)),
          const SizedBox(width: 10), const Text('PILIH SENDER', style: TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1)),
          const Spacer(),
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: _C.green.withOpacity(0.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: _C.green.withOpacity(0.4))), child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.green, boxShadow: [BoxShadow(color: Color(0x5522C55E), blurRadius: 6)])),
            const SizedBox(width: 5), Text('${_globalSenders.isNotEmpty ? _globalSenders.length : 0} online', style: const TextStyle(color: _C.green, fontSize: 11, fontWeight: FontWeight.w700)),
          ])),
        ])),
        Padding(padding: const EdgeInsets.all(14), child: Row(children: [
          Expanded(child: _SenderOptionNew(icon: Icons.person_rounded, label: 'Pribadi', sublabel: 'Private Mode', selected: _senderType == 'private', locked: false, selectedColor: _C.cyan, onTap: () => setState(() => _senderType = 'private'))),
          const SizedBox(width: 8),
          Expanded(child: _SenderOptionNew(icon: Icons.public_rounded, label: 'Publik', sublabel: _isLoadingSenders ? '...' : '${_globalSenders.length} Avail', selected: _senderType == 'public', locked: false, selectedColor: _C.blueMid, onTap: () {
             setState(() => _senderType = 'public'); 
             _loadGlobalSenders();
          })),
          const SizedBox(width: 8),
          Expanded(child: _SenderOptionNew(icon: Icons.auto_awesome_rounded, label: 'GOIB', sublabel: 'Special', selected: _senderType == 'goib', locked: !canAccessGoib, selectedColor: _C.purple, onTap: () {
            if(!canAccessGoib) {
               _showAlert('Locked', 'Fitur Goib belum tersedia.');
               return;
            }
            setState(() => _senderType = 'goib');
          })),
        ])),
        Padding(padding: const EdgeInsets.only(left: 14, right: 14, bottom: 12), child: Row(children: [
          Icon(Icons.info_outline_rounded, color: _C.textDim, size: 12), 
          const SizedBox(width: 6),
          Expanded(child: Text(
            _senderType == 'private' ? 'Menggunakan akun sendiri.' : 
            _senderType == 'public' ? 'Sender publik terbuka untuk semua user.' :
            'Mode khusus dengan prioritas tinggi.', 
            style: const TextStyle(color: _C.textDim, fontSize: 11),
          )),
        ])),
      ]),
    );
  }

  Widget _buildCustomLoopSection() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xBB0D1B2A), 
        borderRadius: BorderRadius.circular(18), 
        border: Border.all(color: _C.purple.withOpacity(0.3))
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: _C.purple.withOpacity(0.15), 
              borderRadius: BorderRadius.circular(10), 
              border: Border.all(color: _C.purple.withOpacity(0.4))
            ),
            child: const Icon(Icons.repeat_rounded, color: _C.purple, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: loopCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w600),
              decoration: InputDecoration(
                hintText: 'Jumlah Loop Video (Default: 2)',
                hintStyle: TextStyle(color: _C.textDim.withOpacity(0.6), fontSize: 13),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _C.purple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8)
            ),
            child: const Text("X", style: TextStyle(color: _C.purple, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _sendBtnCtrl,
      builder: (_, __) => GestureDetector(
        onTap: _isSending ? null : _sendBug,
        child: Transform.scale(
          scale: _isSending ? 1.0 : _sendPulse.value,
          child: Container(
            height: 62, width: double.infinity,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1B6FBD), Color(0xFF2D8FE8), Color(0xFF56AEF5)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [BoxShadow(color: _C.blueMid.withOpacity(_isSending ? 0.2 : _sendGlow.value * 0.55), blurRadius: 28, offset: const Offset(0, 8))]
            ),
            child: Stack(children: [
              Center(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  child: _isSending
                      ? const Row(key: ValueKey('sending'), mainAxisSize: MainAxisSize.min, children: [SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)), SizedBox(width: 12), Text('Mengirim Bug...', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))])
                      : const Row(key: ValueKey('idle'), mainAxisSize: MainAxisSize.min, children: [Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22), SizedBox(width: 12), Text('KIRIM BUG ATTACK', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 1.2))]),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildResultBanner() {
    if (_responseMsg == null) return const SizedBox();
    final parts = _responseMsg!.split('|');
    final type  = parts[0];
    final msg   = parts.length > 1 ? parts[1] : '';

    Color color; IconData icon;
    switch (type) {
      case 'success': color = _C.green;  icon = Icons.check_circle_rounded; break;
      case 'warning': color = _C.amber;  icon = Icons.warning_rounded; break;
      default:        color = _C.red;    icon = Icons.error_rounded;
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(position: _resultSlide, child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(0.35)), boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 16)]),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 32, height: 32, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.12)), child: Icon(icon, color: color, size: 18)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(type == 'success' ? 'Berhasil' : type == 'warning' ? 'Peringatan' : 'Gagal', style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w700)),
            const SizedBox(height: 3), Text(msg, style: const TextStyle(color: _C.textSub, fontSize: 12, height: 1.4)),
          ])),
          GestureDetector(onTap: () { setState(() => _responseMsg = null); _resultCtrl.reset(); }, child: const Icon(Icons.close_rounded, color: _C.textDim, size: 16)),
        ]),
      )),
    );
  }
}

// ─── Widgets ──────────────────────────────────────────────────────────────────

class _ModeTab extends StatelessWidget {
  final IconData icon; final String label; final bool active; final VoidCallback onTap;
  const _ModeTab({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: GestureDetector(onTap: onTap, child: AnimatedContainer(duration: const Duration(milliseconds: 220), padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: active ? _C.blueMid.withOpacity(0.2) : Colors.transparent, borderRadius: BorderRadius.circular(12), border: active ? Border.all(color: _C.blueMid.withOpacity(0.4)) : null), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 16, color: active ? _C.blueLight : _C.textDim), const SizedBox(width: 7), Text(label, style: TextStyle(color: active ? _C.blueLight : _C.textDim, fontSize: 13, fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
    ]))));
  }
}

class _BugInput extends StatefulWidget {
  final TextEditingController controller; final String hint; final TextInputType keyboardType; final IconData icon;
  const _BugInput({required this.controller, required this.hint, required this.keyboardType, required this.icon});

  @override
  State<_BugInput> createState() => _BugInputState();
}

class _BugInputState extends State<_BugInput> {
  bool _focused = false; final _focus = FocusNode();

  @override void initState() { super.initState(); _focus.addListener(() => setState(() => _focused = _focus.hasFocus)); }
  @override void dispose() { _focus.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {
    return AnimatedContainer(duration: const Duration(milliseconds: 200), decoration: BoxDecoration(color: Colors.white.withOpacity(_focused ? 0.08 : 0.04), borderRadius: BorderRadius.circular(14), border: Border.all(color: _focused ? _C.cyan.withOpacity(0.5) : Colors.white.withOpacity(0.1), width: _focused ? 1.5 : 1.0), boxShadow: _focused ? [BoxShadow(color: _C.cyan.withOpacity(0.12), blurRadius: 14, offset: const Offset(0, 4))] : []), child: TextField(controller: widget.controller, focusNode: _focus, keyboardType: widget.keyboardType, style: const TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w500), cursorColor: _C.cyan, decoration: InputDecoration(hintText: widget.hint, hintStyle: const TextStyle(color: _C.textDim, fontSize: 13), prefixIcon: Icon(widget.icon, color: _focused ? _C.cyan : _C.textSub, size: 18), border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16))));
  }
}

class _SenderOptionNew extends StatefulWidget {
  final IconData icon; final String label; final String sublabel; final bool selected; final bool locked; final Color selectedColor; final VoidCallback onTap;
  const _SenderOptionNew({required this.icon, required this.label, required this.sublabel, required this.selected, required this.locked, required this.selectedColor, required this.onTap});

  @override State<_SenderOptionNew> createState() => _SenderOptionNewState();
}

class _SenderOptionNewState extends State<_SenderOptionNew> {
  bool _pressed = false;

  @override Widget build(BuildContext context) {
    return GestureDetector(onTapDown: (_) => setState(() => _pressed = true), onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); }, onTapCancel: () => setState(() => _pressed = false), child: AnimatedScale(scale: _pressed ? 0.96 : 1.0, duration: const Duration(milliseconds: 120), child: AnimatedContainer(duration: const Duration(milliseconds: 200), padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8), decoration: BoxDecoration(color: widget.selected ? widget.selectedColor.withOpacity(0.85) : Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(14), border: Border.all(color: widget.selected ? widget.selectedColor : Colors.white.withOpacity(0.1), width: widget.selected ? 1.5 : 1), boxShadow: widget.selected ? [BoxShadow(color: widget.selectedColor.withOpacity(0.3), blurRadius: 12)] : []), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Stack(clipBehavior: Clip.none, children: [Icon(widget.icon, color: widget.selected ? Colors.white : _C.textSub, size: 22), if (widget.locked) Positioned(right: -4, top: -4, child: Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.amber, border: Border.all(color: Colors.black26, width: 1.5)), child: const Icon(Icons.lock_rounded, color: Colors.white, size: 7)))]),
      const SizedBox(height: 8), Text(widget.label, style: TextStyle(color: widget.selected ? Colors.white : _C.textSub, fontSize: 13, fontWeight: FontWeight.w800)),
      const SizedBox(height: 3), Text(widget.sublabel, textAlign: TextAlign.center, style: TextStyle(color: widget.selected ? Colors.white.withOpacity(0.7) : _C.textDim, fontSize: 10, height: 1.3)),
    ]))));
  }
}

class _DotsLoader extends StatefulWidget {
  const _DotsLoader();
  @override State<_DotsLoader> createState() => _DotsLoaderState();
}
class _DotsLoaderState extends State<_DotsLoader> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override void initState() { super.initState(); _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(); }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return AnimatedBuilder(animation: _c, builder: (_, __) => Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) {
      final t = ((_c.value - i / 3) % 1.0).clamp(0.0, 1.0); final s = math.sin(t * math.pi);
      return Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: Transform.scale(scale: 0.4 + s * 0.6, child: Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.blueMid.withOpacity(0.4 + s * 0.6)))));
    })));
  }
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller; const _AnimatedBg({required this.controller});
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: controller, builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)));
}
class _BgPainter extends CustomPainter {
  final double t; _BgPainter(this.t);
  @override void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = Colors.white.withOpacity(0.03)..strokeWidth = 0.5; const step = 38.0;
    for (double x = 0; x < size.width; x += step) canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += step) canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    final glow = Paint()..shader = RadialGradient(colors: [_C.blue.withOpacity(0.05 + math.sin(t * math.pi * 2) * 0.02), Colors.transparent], radius: 0.9).createShader(Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }
  @override bool shouldRepaint(_BgPainter old) => old.t != t;
}

class _GradBtn extends StatefulWidget {
  final String label; final VoidCallback onTap; final bool fullWidth;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false});
  @override State<_GradBtn> createState() => _GradBtnState();
}
class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(13),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(
                      color: _C.blueMid.withOpacity(0.3),
                      blurRadius: 14,
                      offset: const Offset(0, 4),
                    ),
                  ],
          ),
          child: Center(
            child: Text(
              widget.label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ),
      ),
    );
  }
}