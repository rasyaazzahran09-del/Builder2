import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with TickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;

  // Animation
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // --- TEMA NEON (DIUBAH KE static const) ---
  static const Color bgBlack = Color(0xFF050505);
  static const Color cardBlack = Color(0xFF141414);
  static const Color primaryPurple = Color(0xFFD500F9);
  static const Color primaryPink = Color(0xFFFF4081);
  static const Color successGreen = Color(0xFF00E676);
  static const Color dangerRed = Color(0xFFFF1744);
  static const Color cyberBlue = Color(0xFF00B0FF);

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
    _animationController.forward();
    _fetchSenders();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // --- FETCH DATA ---
  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http
          .get(
            Uri.parse(
                "http://panel-legal.jhonaley.net:2983/mySender?key=${widget.sessionKey}"),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            senderList = data["connections"] ?? [];
          });
        } else {
          setState(() {
            errorMessage = data["message"] ?? "Failed to fetch data";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  // --- FITUR GHOIB ---
  Future<void> _generateGhoibSenders(int count) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: cardBlack,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: cyberBlue)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: cyberBlue),
              const SizedBox(width: 20),
              Text("Generating $count Ghost Numbers...",
                  style: const TextStyle(color: Colors.white)),
            ],
          ),
        ),
      ),
    );

    try {
      final response = await http.post(
        Uri.parse(
            "http://panel-legal.jhonaley.net:2983/api/generate-sender-ghoib"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "key": widget.sessionKey,
          "quantity": count,
        }),
      ).timeout(const Duration(seconds: 30));

      if (mounted) Navigator.pop(context); // Close loading

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = jsonDecode(response.body);
        if (data["success"] == true) {
          _showSnackBar("${data['count'] ?? count} Ghoib Senders Generated!",
              isError: false);
          _fetchSenders();
        } else {
          _showSnackBar(data['message'] ?? "Failed to generate", isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _showSnackBar("Error generating: $e", isError: true);
    }
  }

  void _showAddMenuDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.4,
        decoration: BoxDecoration(
          color: cardBlack,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border:
              Border(top: BorderSide(color: primaryPurple.withOpacity(0.3))),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 30),
              decoration: BoxDecoration(
                color: Colors.grey,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Text("SELECT MODE",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
            const SizedBox(height: 25),
            _buildModeButton(
              icon: Icons.person_add_alt_1,
              color: primaryPink,
              label: "ADD PRIVATE SENDER",
              desc: "Connect via Pairing Code",
              onTap: () {
                Navigator.pop(context);
                _showPrivateAddDialog();
              },
            ),
            const SizedBox(height: 15),
            _buildModeButton(
              icon: Icons.person_off,
              color: cyberBlue,
              label: "GENERATE GHOIB SENDER",
              desc: "Create Random Virtual Number",
              onTap: () {
                Navigator.pop(context);
                _showGhoibConfigDialog();
              },
            ),
            const SizedBox(height: 20),
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("CANCEL",
                    style: TextStyle(color: Colors.white54)))
          ],
        ),
      ),
    );
  }

  Widget _buildModeButton({
    required IconData icon,
    required Color color,
    required String label,
    required String desc,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 30),
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                  const SizedBox(height: 2),
                  Text(desc,
                      style: TextStyle(color: Colors.white60, fontSize: 12))
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: color, size: 16),
          ],
        ),
      ),
    );
  }

  void _showGhoibConfigDialog() {
    int count = 10;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialogState) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBlack,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: cyberBlue),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.auto_fix_high, color: cyberBlue, size: 50),
                const SizedBox(height: 10),
                const Text("Ghost Generator Config",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                const Text("How many numbers to generate?",
                    style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.remove_circle, color: cyberBlue),
                      onPressed: () => setDialogState(
                          () => count = (count > 1) ? count - 1 : 1),
                    ),
                    Text("$count",
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold)),
                    IconButton(
                      icon: Icon(Icons.add_circle, color: cyberBlue),
                      onPressed: () => setDialogState(() => count++),
                    )
                  ],
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: cyberBlue,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                  onPressed: () {
                    Navigator.pop(context);
                    _generateGhoibSenders(count);
                  },
                  child: const Text("SUMMON NOW"),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- DIALOG ADD PRIVATE & LANGSUNG CONNECT KE WHATSAPP ---
  void _showPrivateAddDialog() {
    final phoneController = TextEditingController();
    final nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBlack,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: primaryPink.withOpacity(0.3)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: primaryPink.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.phone_android,
                          color: primaryPink, size: 24),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      "Connect WhatsApp",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                // Input Nama
                const Text("Name (Optional)",
                    style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(
                  controller: nameController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: "Sender name",
                    hintStyle:
                        TextStyle(color: Colors.white.withOpacity(0.4)),
                    prefixIcon:
                        Icon(Icons.person, color: primaryPink, size: 20),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            BorderSide(color: primaryPink.withOpacity(0.3))),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: primaryPink)),
                  ),
                ),
                const SizedBox(height: 16),
                // Input Nomor HP
                const Text("Phone Number",
                    style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: "628xxxxxxxxxx",
                    hintStyle:
                        TextStyle(color: Colors.white.withOpacity(0.4)),
                    prefixIcon:
                        Icon(Icons.phone, color: primaryPink, size: 20),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            BorderSide(color: primaryPink.withOpacity(0.3))),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: primaryPink)),
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("CANCEL",
                          style: TextStyle(color: Colors.white54)),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: primaryPink,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12))),
                      onPressed: () async {
                        final number = phoneController.text.trim();
                        final name = nameController.text.trim();

                        if (number.isEmpty) {
                          _showSnackBar("Please enter phone number",
                              isError: true);
                          return;
                        }

                        Navigator.pop(context);
                        await _connectAndGetPairingCode(number, name);
                      },
                      child: const Text("CONNECT",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- LOGIKA CONNECT DAN AMBIL PAIRING CODE ---
  Future<void> _connectAndGetPairingCode(String number, String name) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
              color: cardBlack,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: primaryPink)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: primaryPink),
              const SizedBox(height: 16),
              const Text("Requesting Pairing Code...",
                  style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
      ),
    );

    try {
      final response = await http
          .get(
            Uri.parse(
                "http://panel-legal.jhonaley.net:2983/getPairing?key=${widget.sessionKey}&number=$number"),
          )
          .timeout(const Duration(seconds: 20));

      if (mounted) Navigator.pop(context);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true && data['pairingCode'] != null) {
          _showSnackBar("Pairing code generated!", isError: false);
          _showPairingCodeDialog(number, data['pairingCode'], name);
        } else {
          _showSnackBar(data['message'] ?? "Failed to generate pairing code",
              isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      _fetchSenders();
    }
  }

  // --- DIALOG PAIRING CODE ---
  void _showPairingCodeDialog(String number, String code, String name) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            decoration: BoxDecoration(
              color: cardBlack,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                  color: primaryPink.withOpacity(0.5), width: 1.5),
            ),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: primaryPink.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child:
                      Icon(Icons.qr_code_2, color: primaryPink, size: 40),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Pairing Required",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: bgBlack,
                    borderRadius: BorderRadius.circular(20),
                    border:
                        Border.all(color: primaryPink.withOpacity(0.3)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (name.isNotEmpty) ...[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.person, color: primaryPink, size: 16),
                            const SizedBox(width: 8),
                            Text(name,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16)),
                          ],
                        ),
                        const SizedBox(height: 12),
                      ],
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.phone, color: primaryPink, size: 16),
                          const SizedBox(width: 8),
                          Text(number,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 14)),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: cardBlack,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: primaryPink, width: 2),
                          boxShadow: [
                            BoxShadow(
                                color: primaryPink.withOpacity(0.4),
                                blurRadius: 15,
                                offset: Offset.zero),
                          ],
                        ),
                        child: Text(
                          code,
                          style: const TextStyle(
                            color: primaryPink,
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 6,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: primaryPink.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          "Open WhatsApp > Settings > Linked Devices\n> Link a Device > Enter this code",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("CLOSE",
                          style: TextStyle(color: Colors.white54)),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: primaryPink,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12))),
                      onPressed: () {
                        Navigator.pop(context);
                        _refreshSenders();
                      },
                      child: const Text("REFRESH LIST",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: Colors.white,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(message,
                style: const TextStyle(color: Colors.white, fontSize: 14)),
          ),
        ],
      ),
      backgroundColor: isError ? dangerRed : successGreen,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  // --- DELETE SENDER ---
  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBlack,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: dangerRed.withOpacity(0.5)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: dangerRed.withOpacity(0.2),
                    shape: BoxShape.circle,
                    border: Border.all(color: dangerRed, width: 2),
                  ),
                  child: Icon(Icons.warning_amber_rounded,
                      color: dangerRed, size: 40),
                ),
                const SizedBox(height: 20),
                const Text("Confirm Delete",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                const Text("Are you sure you want to delete this sender?",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text("CANCEL",
                            style: TextStyle(color: Colors.white54))),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: dangerRed,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12))),
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text("DELETE",
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);
      try {
        final response = await http.delete(
          Uri.parse(
              "http://panel-legal.jhonaley.net:2983/deleteSender?key=${widget.sessionKey}&id=$senderId"),
        ).timeout(const Duration(seconds: 15));

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted successfully!", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to delete",
                isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: const Text("SENDER MANAGER",
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                letterSpacing: 2)),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white70, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: isLoading ? null : _refreshSenders,
          )
        ],
      ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: [primaryPurple, primaryPink]),
            boxShadow: [
              BoxShadow(color: primaryPurple.withOpacity(0.5), blurRadius: 10)
            ]),
        child: FloatingActionButton(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add, color: Colors.white, size: 28),
          onPressed: _showAddMenuDialog,
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgBlack, Color(0xFF0a0514)],
          ),
        ),
        child: Builder(
          builder: (context) {
            if (isLoading && senderList.isEmpty) {
              return Center(
                  child: CircularProgressIndicator(color: primaryPurple));
            }

            if (errorMessage != null && senderList.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 80, color: dangerRed),
                    const SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Text(errorMessage!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70)),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: primaryPurple),
                      onPressed: _fetchSenders,
                      child: const Text("TRY AGAIN"),
                    )
                  ],
                ),
              );
            }

            if (senderList.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.phone_disabled,
                        size: 80, color: Colors.white12),
                    const SizedBox(height: 20),
                    const Text("No Senders Found",
                        style:
                            TextStyle(color: Colors.white54, fontSize: 18)),
                    const SizedBox(height: 8),
                    const Text("Tap + to add Private or Ghoib",
                        style: TextStyle(color: Colors.white24, fontSize: 12))
                  ],
                ),
              );
            }

            return RefreshIndicator(
              color: primaryPurple,
              backgroundColor: cardBlack,
              onRefresh: _refreshSenders,
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 16, bottom: 80),
                itemCount: senderList.length,
                itemBuilder: (context, index) {
                  var item = senderList[index];
                  bool isGlobal = item['type'] == 'global';
                  bool isActive = item['status'] == 'active';

                  return FadeTransition(
                    opacity: _fadeAnimation,
                    child: Container(
                      margin: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: cardBlack.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: isGlobal
                                ? cyberBlue.withOpacity(0.3)
                                : primaryPurple.withOpacity(0.2)),
                        boxShadow: [
                          BoxShadow(
                              color: isGlobal
                                  ? cyberBlue.withOpacity(0.05)
                                  : Colors.black45,
                              blurRadius: 10)
                        ],
                      ),
                      child: Column(
                        children: [
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: isGlobal
                                    ? cyberBlue.withOpacity(0.2)
                                    : primaryPink.withOpacity(0.2),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                isGlobal
                                    ? Icons.person_off
                                    : Icons.smartphone,
                                color:
                                    isGlobal ? cyberBlue : primaryPink,
                              ),
                            ),
                            title: Text(
                              item['sessionName'] ?? 'Unknown',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15),
                            ),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 6.0),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['phone'] ?? item['id'] ?? '',
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontFamily: 'monospace',
                                        fontSize: 13),
                                  ),
                                  const SizedBox(height: 6),
                                  Row(
                                    children: [
                                      Container(
                                        padding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 8,
                                                vertical: 3),
                                        decoration: BoxDecoration(
                                          color: isGlobal
                                              ? cyberBlue
                                                  .withOpacity(0.15)
                                              : Colors.white10,
                                          borderRadius:
                                              BorderRadius.circular(6),
                                          border: Border.all(
                                              color: isGlobal
                                                  ? cyberBlue
                                                      .withOpacity(0.5)
                                                  : Colors.white24),
                                        ),
                                        child: Text(
                                          isGlobal
                                              ? "GHOIB"
                                              : "PRIVATE",
                                          style: TextStyle(
                                              color: isGlobal
                                                  ? cyberBlue
                                                  : Colors.white70,
                                              fontSize: 10,
                                              fontWeight:
                                                  FontWeight.bold),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        padding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 8,
                                                vertical: 3),
                                        decoration: BoxDecoration(
                                          color: isActive
                                              ? successGreen
                                                  .withOpacity(0.15)
                                              : dangerRed
                                                  .withOpacity(0.15),
                                          borderRadius:
                                              BorderRadius.circular(6),
                                        ),
                                        child: Row(
                                          mainAxisSize:
                                              MainAxisSize.min,
                                          children: [
                                            Icon(
                                              Icons.circle,
                                              size: 6,
                                              color: isActive
                                                  ? successGreen
                                                  : dangerRed,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              isActive
                                                  ? "ACTIVE"
                                                  : "OFFLINE",
                                              style: TextStyle(
                                                  color: isActive
                                                      ? successGreen
                                                      : dangerRed,
                                                  fontSize: 10,
                                                  fontWeight:
                                                      FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  icon: Icon(Icons.refresh,
                                      size: 16,
                                      color: primaryPurple),
                                  label: const Text("REFRESH",
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold)),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: primaryPurple,
                                    side: BorderSide(
                                        color: primaryPurple
                                            .withOpacity(0.5)),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                  ),
                                  onPressed: () => _refreshSenders(),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: OutlinedButton.icon(
                                  icon: Icon(Icons.delete_outline,
                                      size: 16, color: dangerRed),
                                  label: const Text("DELETE",
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold)),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: dangerRed,
                                    side: BorderSide(
                                        color: dangerRed
                                            .withOpacity(0.5)),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                  ),
                                  onPressed: () => _deleteSender(
                                      item['id'] ?? ''),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}