/**
 * VTX SERVER — index.js
 * ============================================================
 * Fitur yang didukung:
 *  - Chat Public (room global)
 *  - Chat Private (room per pasangan user)
 *  - Kirim: teks, gambar, video, audio, ZIP, file
 *  - Voice Call & Video Call (WebRTC signaling via Socket.IO)
 *  - Status / Story (buat, lihat, tandai viewed)
 *  - Auth via token (sessionKey dari app)
 * ============================================================
 * Instalasi:
 *   npm init -y
 *   npm install express socket.io multer cors jsonwebtoken uuid dotenv
 * ============================================================
 */

'use strict';

const express   = require('express');
const http      = require('http');
const { Server }= require('socket.io');
const multer    = require('multer');
const cors      = require('cors');
const path      = require('path');
const fs        = require('fs');
const { v4: uuid } = require('uuid');
require('dotenv').config();

// ─────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────
const PORT        = process.env.PORT        || 3000;
const JWT_SECRET  = process.env.JWT_SECRET  || 'vtx-secret-key-change-in-prod';
const UPLOAD_DIR  = process.env.UPLOAD_DIR  || path.join(__dirname, 'uploads');
const STATUS_DIR  = process.env.STATUS_DIR  || path.join(__dirname, 'uploads', 'status');
const MAX_FILE_MB = parseInt(process.env.MAX_FILE_MB || '100', 10);

// Buat direktori jika belum ada
[UPLOAD_DIR, STATUS_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ─────────────────────────────────────────────
// IN-MEMORY STORES
// (Ganti dengan database seperti MongoDB/PostgreSQL di produksi)
// ─────────────────────────────────────────────
const messages       = {};   // { [roomId]: ChatMessage[] }
const statuses       = [];   // UserStatus[]
const conversations  = {};   // { [username]: Set<peerUsername> }
const onlineUsers    = {};   // { [socketId]: { username, token } }

// ─────────────────────────────────────────────
// APP SETUP
// ─────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: {
    origin : '*',
    methods: ['GET', 'POST'],
  },
  maxHttpBufferSize: MAX_FILE_MB * 1024 * 1024,
});

app.use(cors());
app.use(express.json({ limit: `${MAX_FILE_MB}mb` }));
app.use('/uploads', express.static(UPLOAD_DIR));

// ─────────────────────────────────────────────
// MULTER (FILE UPLOAD)
// ─────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dest = req.path.includes('status') ? STATUS_DIR : UPLOAD_DIR;
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext  = path.extname(file.originalname) || '';
    cb(null, `${Date.now()}_${uuid()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    // Izinkan semua tipe file (image, video, audio, zip, etc.)
    cb(null, true);
  },
});

// ─────────────────────────────────────────────
// AUTH MIDDLEWARE (HTTP)
// ─────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.replace('Bearer ', '').trim();
  if (!token) return res.status(401).json({ error: 'No token' });
  // Verifikasi token — di sini pakai simple check,
  // di produksi gunakan jwt.verify(token, JWT_SECRET)
  req.username = token; // Sementara: token IS username (sesuai app Flutter)
  next();
}

// ─────────────────────────────────────────────
// HEALTH CHECK
// ─────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    status : 'OK',
    name   : 'VTX Server',
    version: '1.0.0',
    time   : new Date().toISOString(),
  });
});

// ─────────────────────────────────────────────
// CHAT API
// ─────────────────────────────────────────────

/**
 * GET /chat/history/:roomId
 * Ambil riwayat pesan sebuah room
 */
app.get('/chat/history/:roomId', authMiddleware, (req, res) => {
  const { roomId } = req.params;
  const msgs = (messages[roomId] || []).slice(-200); // max 200 pesan terakhir
  res.json({ messages: msgs });
});

/**
 * GET /chat/conversations
 * Ambil daftar percakapan private user
 */
app.get('/chat/conversations', authMiddleware, (req, res) => {
  const me    = req.username;
  const peers = conversations[me] ? [...conversations[me]] : [];
  const list  = peers.map(peer => {
    const roomId   = privateRoomId(me, peer);
    const msgs     = messages[roomId] || [];
    const lastMsg  = msgs.length > 0 ? msgs[msgs.length - 1] : null;
    return {
      peerUsername: peer,
      lastMessage : lastMsg ? lastMsg.content : '',
      time        : lastMsg ? formatTime(new Date(lastMsg.time)) : '',
    };
  });
  res.json({ conversations: list });
});

/**
 * POST /chat/upload
 * Upload file untuk dikirim di chat
 */
app.post('/chat/upload', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const url = `${getBaseUrl(req)}/uploads/${req.file.filename}`;
  res.json({ url, filename: req.file.originalname });
});

// ─────────────────────────────────────────────
// STATUS / STORY API
// ─────────────────────────────────────────────

/**
 * GET /status/all
 * Ambil semua status aktif (dalam 24 jam terakhir)
 */
app.get('/status/all', authMiddleware, (req, res) => {
  const cutoff = Date.now() - 24 * 60 * 60 * 1000; // 24 jam
  const active = statuses.filter(s => new Date(s.createdAt).getTime() > cutoff);
  res.json({ statuses: active });
});

/**
 * POST /status/create
 * Buat status baru (text type — sudah ada URL dari upload sebelumnya)
 */
app.post('/status/create', authMiddleware, (req, res) => {
  const { mediaUrl, mediaType, caption } = req.body;
  const newStatus = {
    id       : uuid(),
    username : req.username,
    mediaUrl : mediaUrl || '',
    mediaType: mediaType || 'text',
    caption  : caption || '',
    createdAt: new Date().toISOString(),
    viewers  : [],
  };
  statuses.push(newStatus);

  // Broadcast ke semua socket yang online
  io.emit('new_status', newStatus);

  res.json({ success: true, status: newStatus });
});

/**
 * POST /status/upload
 * Upload media untuk status
 */
app.post('/status/upload', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const url = `${getBaseUrl(req)}/uploads/status/${req.file.filename}`;
  res.json({ url, filename: req.file.originalname });
});

/**
 * POST /status/view/:id
 * Tandai status sudah dilihat
 */
app.post('/status/view/:id', authMiddleware, (req, res) => {
  const { id }   = req.params;
  const viewer   = req.username;
  const status   = statuses.find(s => s.id === id);
  if (!status) return res.status(404).json({ error: 'Status not found' });
  if (!status.viewers.includes(viewer)) {
    status.viewers.push(viewer);
  }
  res.json({ success: true });
});

// ─────────────────────────────────────────────
// SOCKET.IO
// ─────────────────────────────────────────────
io.use((socket, next) => {
  const token = socket.handshake.auth?.token || socket.handshake.query?.token;
  if (!token) return next(new Error('Authentication error'));
  socket.username = token; // token IS username (sesuai app Flutter)
  next();
});

io.on('connection', (socket) => {
  const username = socket.username;
  onlineUsers[socket.id] = { username };
  console.log(`[CONNECT] ${username} (${socket.id})`);

  // ── JOIN ROOM ──────────────────────────────
  socket.on('join_room', ({ room }) => {
    socket.join(room);
    console.log(`[JOIN] ${username} → ${room}`);
  });

  // ── SEND MESSAGE ──────────────────────────
  socket.on('send_message', (data) => {
    const { room, content, type, senderName, fileUrl, fileName } = data;
    if (!room || content === undefined) return;

    const msg = {
      id        : uuid(),
      senderId  : username,
      senderName: senderName || username,
      content   : content || '',
      type      : type || 'text',
      time      : new Date().toISOString(),
      fileUrl   : fileUrl || null,
      fileName  : fileName || null,
    };

    // Simpan ke memory
    if (!messages[room]) messages[room] = [];
    messages[room].push(msg);

    // Simpan percakapan private
    if (room.startsWith('private_')) {
      const parts = room.replace('private_', '').split('_');
      if (parts.length >= 2) {
        const peer = parts.find(p => p !== username);
        if (peer) {
          if (!conversations[username]) conversations[username] = new Set();
          if (!conversations[peer])    conversations[peer]     = new Set();
          conversations[username].add(peer);
          conversations[peer].add(username);
        }
      }
    }

    // Broadcast ke room
    io.to(room).emit('new_message', msg);
    console.log(`[MSG] ${username} → ${room}: ${content.substring(0, 50)}`);
  });

  // ── CALL SIGNALING ─────────────────────────

  // Mulai panggilan
  socket.on('initiate_call', ({ room, caller, callee, type }) => {
    socket.join(room);
    socket.to(room).emit('incoming_call', { caller, callee, type, room });
    console.log(`[CALL] ${caller} → ${callee} (${type})`);
  });

  // Terima panggilan
  socket.on('accept_call', ({ room }) => {
    socket.join(room);
    io.to(room).emit('call_accepted', { room });
    console.log(`[CALL ACCEPTED] ${username} room=${room}`);
  });

  // Tolak panggilan
  socket.on('reject_call', ({ room }) => {
    io.to(room).emit('call_rejected', { room });
    console.log(`[CALL REJECTED] ${username} room=${room}`);
  });

  // Akhiri panggilan
  socket.on('end_call', ({ room }) => {
    io.to(room).emit('call_ended', { room });
    console.log(`[CALL ENDED] ${username} room=${room}`);
  });

  // WebRTC Signaling (offer/answer/candidate)
  socket.on('webrtc_offer', ({ room, offer }) => {
    socket.to(room).emit('webrtc_offer', { offer, from: username });
  });

  socket.on('webrtc_answer', ({ room, answer }) => {
    socket.to(room).emit('webrtc_answer', { answer, from: username });
  });

  socket.on('webrtc_ice_candidate', ({ room, candidate }) => {
    socket.to(room).emit('webrtc_ice_candidate', { candidate, from: username });
  });

  // ── DISCONNECT ────────────────────────────
  socket.on('disconnect', () => {
    delete onlineUsers[socket.id];
    console.log(`[DISCONNECT] ${username} (${socket.id})`);
  });
});

// ─────────────────────────────────────────────
// HELPER FUNCTIONS
// ─────────────────────────────────────────────
function privateRoomId(a, b) {
  return 'private_' + [a, b].sort().join('_');
}

function formatTime(date) {
  const now   = new Date();
  const diffMs= now - date;
  const diffM = Math.floor(diffMs / 60000);
  if (diffM < 1)  return 'Baru saja';
  if (diffM < 60) return `${diffM}m`;
  const diffH = Math.floor(diffM / 60);
  if (diffH < 24) return `${diffH}j`;
  return `${Math.floor(diffH / 24)}h`;
}

function getBaseUrl(req) {
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  return `${proto}://${req.headers.host}`;
}

// ─────────────────────────────────────────────
// ERROR HANDLERS
// ─────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.message);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]', err);
});

process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason);
});

// ─────────────────────────────────────────────
// START SERVER
// ─────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║  VTX SERVER RUNNING ON PORT ${PORT}     ║`);
  console.log(`╚══════════════════════════════════════╝\n`);
  console.log(`  ✅ HTTP   : http://0.0.0.0:${PORT}`);
  console.log(`  ✅ WS     : ws://0.0.0.0:${PORT}`);
  console.log(`  ✅ Uploads: ${UPLOAD_DIR}\n`);
});

module.exports = { app, server, io };
